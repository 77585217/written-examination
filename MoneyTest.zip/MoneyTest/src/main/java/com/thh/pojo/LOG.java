package com.thh.pojo;

import java.util.Date;

public class LOG {
    private Integer id;
    private  String info;
    private Date createDate;

    public Integer getId() {
        return id;
    }

    public String getInfo() {
        return info;
    }

    public Date getcreateDate() {
        return createDate;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public void setInfo(String info) {
        this.info = info;
    }

    public void setcreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public LOG() {
    }

    public LOG(Integer id, String info, Date createDate) {
        this.id = id;
        this.info = info;
        this.createDate = createDate;
    }

    @Override
    public String toString() {
        return "LOG{" +
                "id=" + id +
                ", info='" + info + '\'' +
                ", createDate=" + createDate +
                '}';
    }
}
