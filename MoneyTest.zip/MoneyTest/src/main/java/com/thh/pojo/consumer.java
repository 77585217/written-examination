package com.thh.pojo;

public class consumer {

    private Integer id;
    private String username;
    private Double sumMoney;
    private Double remainMoney;
    private Double consumeMoney;
    private Double ReturnMoney;
    private String info;

    public void setId(Integer id) {
        this.id = id;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public void setSumMoney(Double sumMoney) {
        this.sumMoney = sumMoney;
    }

    public void setRemainMoney(Double remainMoney) {
        this.remainMoney = remainMoney;
    }

    public void setConsumeMoney(Double consumeMoney) {
        this.consumeMoney = consumeMoney;
    }

    public void setReturnMoney(Double returnMoney) {
        ReturnMoney = returnMoney;
    }

    public void setInfo(String info) {
        this.info = info;
    }

    public Integer getId() {
        return id;
    }

    public String getUsername() {
        return username;
    }

    public Double getSumMoney() {
        return sumMoney;
    }

    public Double getRemainMoney() {
        return remainMoney;
    }

    public Double getConsumeMoney() {
        return consumeMoney;
    }

    public Double getReturnMoney() {
        return ReturnMoney;
    }

    public String getInfo() {
        return info;
    }

    public consumer(Integer id, String username, Double sumMoney, Double remainMoney, Double consumeMoney, Double returnMoney, String info) {
        this.id = id;
        this.username = username;
        this.sumMoney = sumMoney;
        this.remainMoney = remainMoney;
        this.consumeMoney = consumeMoney;
        ReturnMoney = returnMoney;
        this.info = info;
    }

    public consumer() {
    }

    @Override
    public String toString() {
        return "consumer{" +
                "id=" + id +
                ", username='" + username + '\'' +
                ", sumMoney=" + sumMoney +
                ", remainMoney=" + remainMoney +
                ", consumeMoney=" + consumeMoney +
                ", ReturnMoney=" + ReturnMoney +
                ", info='" + info + '\'' +
                '}';
    }
}
