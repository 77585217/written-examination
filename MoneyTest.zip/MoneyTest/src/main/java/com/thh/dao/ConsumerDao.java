package com.thh.dao;

import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

public interface ConsumerDao {
    @Select("select remainMoney  from consumer where id = #{id}")
    //查询用户余额
    public Double SelectRemainMoney(int id);
    @Select("select consumeMoney  from consumer where id = #{id}")
    //用户消费的金钱
    public Double SelectConsumeMoney(int id);
    @Select("select ReturnMoney  from consumer where id = #{id}")
    //用户退款的金钱
    public Double SelectReturnMoney(int id);
@Update("update consumer set sum = sum + #{returnMoney}- #{ConsumeMoney} where id = #{id} ")
//    //用户更新数据库金钱
    public void UpdateSumMoney(int id,Double returnMoney ,Double ConsumeMoney);
}
