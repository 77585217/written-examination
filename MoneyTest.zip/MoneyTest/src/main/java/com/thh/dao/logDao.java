package com.thh.dao;

import org.apache.ibatis.annotations.Insert;

public interface logDao {

    @Insert("insert into log (info,createDate) values(#{info},now())")
    void log(String info);
}
