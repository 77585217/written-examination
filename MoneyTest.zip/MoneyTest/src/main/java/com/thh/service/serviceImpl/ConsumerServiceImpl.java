package com.thh.service.serviceImpl;

import com.thh.dao.ConsumerDao;
import com.thh.pojo.consumer;
import com.thh.service.ConsumerService;
import com.thh.service.logService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class ConsumerServiceImpl implements ConsumerService {
    @Autowired
    private ConsumerDao consumerDao;
    private com.thh.service.logService logService;

    public Double SelectRemainMoney(int id) {

        return  consumerDao.SelectRemainMoney(id);
    }

    public Double SelectConsumeMoney(int id) {
        return consumerDao.SelectConsumeMoney(id);
    }

    public Double SelectReturnMoney(int id) {
        return consumerDao.SelectReturnMoney(id);
    }
@Transactional
    public void  UpdateSumMoney(int id,Double returnMoney, Double  ConsumeMoney) {
try{
    Double consumeMoney = consumerDao.SelectConsumeMoney(id);
    Double returnMoney1 = consumerDao.SelectReturnMoney(id);
    consumerDao.UpdateSumMoney(id,returnMoney1,consumeMoney);
}finally {
logService.info(id,returnMoney,ConsumeMoney);
}


    }
}
