package com.thh.config;

import com.alibaba.druid.pool.DruidDataSource;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.test.context.event.annotation.BeforeTestExecution;
import org.springframework.transaction.PlatformTransactionManager;

import javax.sql.DataSource;

public class JdbcConfig {
@Value("${jdbc.url}")
    private String  url;
    @Value("${jdbc.password}")
    private  String password;
    @Value("${jdbc.username}")
    private String username;
    @Value("${jdbc.driver}")
    private String DriverName;

    @Bean
    public DataSource dataSource(){

        DruidDataSource d = new DruidDataSource();
        d.setDriverClassName(DriverName);
        d.setPassword(password);
        d.setUrl(url);
        d.setUsername(username);
        return d;
    }

    @Bean
    public PlatformTransactionManager platformTransactionManager(DataSource dataSource){
        DataSourceTransactionManager d = new DataSourceTransactionManager();
        d.setDataSource(dataSource);
        return d;
    }
}
