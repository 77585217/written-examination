import com.alibaba.druid.util.lang.Consumer;
import com.thh.config.SpringConfig;
import com.thh.pojo.consumer;
import com.thh.service.ConsumerService;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = SpringConfig.class)
public class TestDao {
@Autowired
private ConsumerService consumerService;
private com.thh.pojo.consumer consumer;

@Test
public void testremainMoney(){
    Double remainMoney = consumerService.SelectRemainMoney(1);
    System.out.println(remainMoney);

}

    @Test
    public void TestSelectConsumeMoney(){
        Double ConsumeMoney = consumerService.SelectConsumeMoney(1);
        System.out.println(ConsumeMoney);

    }
    @Test
    public void TestSelectReturnMoney(){
        Double returnMoney = consumerService.SelectReturnMoney(1);
        System.out.println(returnMoney);

    }
//    @Test
//    public void TestUpdateSumMoney(){
//
//    consumerService.UpdateSumMoney(1,)
//        System.out.println(remainMoney);
//
//    }


}
