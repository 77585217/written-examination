package com.thh.service;

import org.springframework.transaction.annotation.Transactional;

@Transactional
public interface ConsumerService {

    public Double SelectRemainMoney(int id);

    public Double SelectConsumeMoney(int id);

    public Double SelectReturnMoney(int id);

    public void UpdateSumMoney(int id, Double returnMoney , Double  ConsumeMoney);

}
