package com.thh.service;

import org.springframework.transaction.annotation.Transactional;


public interface logService {

    public void info(int id,Double returnMoney ,Double ConsumeMoney);

}
