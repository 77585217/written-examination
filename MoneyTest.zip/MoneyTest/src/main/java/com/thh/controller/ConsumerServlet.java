package com.thh.controller;

import com.thh.service.ConsumerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/consumers")
public class ConsumerServlet {
    @Autowired
    private ConsumerService consumerService;

    @GetMapping("/{id}")
    public Double SelectConsumeMoney(@PathVariable Integer id) {
        return consumerService.SelectConsumeMoney(id);
    }
    @GetMapping("b/{id}")
    public Double SelectRemainMoney(@PathVariable Integer id) {

        return consumerService.SelectRemainMoney(id);
    }
    @GetMapping("c/{id}")
    public Double SelectReturnMoney(@PathVariable Integer id) {

        return consumerService.SelectReturnMoney(id);
    }
//    @PutMapping("/{sumMoney,returnMoney}")
//    public Double UpdateSumMoney(@PathVariable Integer id, Double sumMoney,Double returnMoney,Double consumeMoney) {
//        return consumerService.UpdateSumMoney(id,sumMoney,returnMoney,consumeMoney);
//    }

}
