package com.thh.service.serviceImpl;

import com.thh.dao.logDao;
import com.thh.service.logService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

public class LogServiceImpl implements logService {

    @Autowired
    private  logDao logDao;
    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void info(int id, Double returnMoney, Double ConsumeMoney) {
        logDao.log("顾客id为"+id+"本次退款"+returnMoney +"元" +"消费"+ConsumeMoney+"元");

    }
}
